import React from 'react';
import './App.css';
import Board from './Components/Board/Board'
function App() {
  return (
    <>
      <Board />
    </>
  );
}
export default App;
